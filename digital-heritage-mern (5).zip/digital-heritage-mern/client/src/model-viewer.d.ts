declare module '*.glb';
